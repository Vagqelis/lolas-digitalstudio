CREATE TABLE public.project_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  business TEXT,
  email TEXT NOT NULL,
  phone TEXT,
  package TEXT NOT NULL,
  message TEXT NOT NULL,
  link TEXT,
  owner_email_sent BOOLEAN NOT NULL DEFAULT false,
  customer_email_sent BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT ALL ON public.project_requests TO service_role;

ALTER TABLE public.project_requests ENABLE ROW LEVEL SECURITY;