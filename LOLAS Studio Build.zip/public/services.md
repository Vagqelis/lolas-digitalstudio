# LOLAS — Digital Studio · Services

Modern, high-quality and affordable web design and development for small and
medium businesses. Websites delivered in **1–2 days**, with a **2-week free
trial** before you pay anything.

- Website: https://lolas-digitalstudio.com
- Email: elolas@tuc.gr
- WhatsApp: +30 698 708 5152
- Languages: English, Ελληνικά, Deutsch

---

## Services

### Web Design
- Modern, minimal, premium visual identity
- Custom layouts — no recycled templates
- Typography, colour and spacing systems built per brand
- Fully responsive design for mobile, tablet and desktop
- Accessible contrast, readable type and clear hierarchy

### Web Development
- Fast, hand-built front-end code
- Multi-page or single-page structures
- Contact forms with validation and email notifications
- WhatsApp, phone and email quick-action buttons
- Google Maps and location embedding
- Social media integration
- Multi-language sites (EN / EL / DE and more)

### Web Applications
- Custom business tools beyond a standard website
- Booking, request, dashboard and internal-tool flows
- Databases, authentication and secure data handling
- Custom forms with server-side processing
- Admin views and role-based access

### Performance & SEO
- Optimised images, fonts and asset loading
- Fast first paint and high Lighthouse scores
- Semantic HTML and correct heading structure
- Meta titles, descriptions and social preview cards
- `sitemap.xml`, `robots.txt` and canonical URLs
- Basic keyword and on-page SEO setup

### Launch & Support
- Domain connection and DNS setup
- Hosting configuration and deployment
- Email notification wiring for leads and requests
- Post-launch fixes and content updates on request

---

## Pricing Tiers

### 01 — LANDING · €250
For businesses that need a professional online presence, fast.

- One-page professional website
- Responsive design, mobile & desktop optimisation
- Contact section
- WhatsApp / phone / email buttons
- Google Maps integration
- Basic SEO setup
- Fast delivery (1–2 days)

### 02 — BUSINESS · €400 — most popular
For businesses that need a complete, multi-page professional website.

- Multi-page website with professional custom design
- Home, about, services / products and contact pages
- Contact form with email notifications
- Google Maps integration
- Social media integration
- Mobile & desktop optimisation
- Basic SEO
- Performance optimisation

### 03 — APP · €800
For businesses that need something more advanced than a standard website.

- Custom web application
- Advanced functionality
- User-friendly interface
- Custom forms and data handling
- Responsive design, mobile & desktop optimisation
- Custom business features
- Deployment and setup

**Not sure which tier fits?** Send a request and we advise you honestly —
including when a cheaper tier is enough.

---

## Technologies We Use

### Front-end
- **React 19** with **TypeScript** for reliable, typed interfaces
- **TanStack Start / TanStack Router** for full-stack routing and SSR
- **Vite** for fast builds and optimised output
- **Tailwind CSS** with a semantic design-token system
- Accessible UI primitives (Radix-based components)

### Back-end & Data
- Server functions for secure, server-side logic
- **PostgreSQL** database with row-level security
- Authentication and role-based access control
- File and image storage
- Transactional email delivery for leads and confirmations

### Infrastructure
- Edge deployment for low latency worldwide
- Custom domain and SSL setup
- Preview environments before going live
- Automated builds on every change

### Quality
- Type-checked code end to end
- Form validation with **Zod** schemas
- Performance, SEO and responsive testing before handover

---

## Our Workflow

1. **Request** — you send your details, your package and what you need through
   the contact form. Only your name, email and package are required.
2. **Confirmation** — you instantly receive a confirmation email, and the studio
   receives your full request so we can reply quickly.
3. **Brief** — a short conversation (WhatsApp or email) to align on goals,
   content, style references and structure.
4. **Design & build** — we design and develop the site, usually within
   **1–2 days**, and send you a live preview link.
5. **Free trial — 2 weeks** — you use the finished website free for two weeks,
   share it with others and request revisions.
6. **Revisions** — we refine copy, layout and details until it is right.
7. **Launch** — you approve and pay, we connect your domain, set up SEO
   essentials and deploy live.
8. **Aftercare** — updates, fixes and small additions whenever you need them.

---

## Get Started

- Request a project: https://lolas-digitalstudio.com/contact
- Packages & pricing: https://lolas-digitalstudio.com/packages
- Email: elolas@tuc.gr
- WhatsApp: +30 698 708 5152
