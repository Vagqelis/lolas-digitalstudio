# Roadmap

- [x] Fix failing SEO findings: contact form label associations, duplicate page title
- [ ] Google Search Console connection/verification (needs user approval)
