import { cn } from "@/lib/utils";

/**
 * LOLAS geometric symbol: an angular L paired with a taupe arc.
 * Works standalone (favicon, footer, section details).
 */
export function LolasMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      role="img"
      aria-label="LOLAS symbol"
      className={cn("h-8 w-8", className)}
    >
      <path d="M14 12h13v62h33v13H14V12z" fill="currentColor" />
      <path
        d="M42 30h9a27 27 0 0 1 0 54h-9V71h9a14 14 0 0 0 0-28h-9V30z"
        fill="var(--taupe)"
      />
    </svg>
  );
}

export function LolasLogo({
  className,
  stacked = false,
}: {
  className?: string;
  stacked?: boolean;
}) {
  return (
    <span
      className={cn(
        "flex items-center gap-3 text-foreground",
        stacked && "flex-col gap-4 text-center",
        className,
      )}
    >
      <LolasMark className="h-7 w-7" />
      <span className={cn("flex flex-col", stacked && "items-center")}>
        <span className="text-[0.95rem] font-semibold leading-none tracking-[0.34em]">
          LOLAS
        </span>
        <span className="mt-1 text-[0.5rem] font-medium leading-none tracking-[0.34em] text-muted-foreground">
          DIGITAL STUDIO
        </span>
      </span>
    </span>
  );
}
