import { Link } from "@tanstack/react-router";

import { LolasMark } from "@/components/LolasMark";
import { useI18n } from "@/lib/i18n";

export function SiteFooter() {
  const { t } = useI18n();

  return (
    <footer className="border-t border-border">
      <div className="container-studio flex flex-col gap-10 py-14 md:flex-row md:items-start md:justify-between">
        <div className="max-w-xs">
          <LolasMark className="h-9 w-9" />
          <p className="mt-5 text-sm font-semibold tracking-[0.34em]">LOLAS</p>
          <p className="mt-1 text-[0.6rem] font-medium tracking-[0.34em] text-muted-foreground">
            DIGITAL STUDIO
          </p>
          <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
            {t.footer.tagline}
          </p>
        </div>

        <div className="flex gap-16">
          <div>
            <p className="label-eyebrow">{t.footer.studio}</p>
            <div className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground">
              <Link to="/services" className="transition-colors hover:text-foreground">
                {t.nav.services}
              </Link>
              <Link to="/packages" className="transition-colors hover:text-foreground">
                {t.nav.packages}
              </Link>
              <Link
                to="/kataskevi-istoselidon-chania"
                className="transition-colors hover:text-foreground"
              >
                Κατασκευή Ιστοσελίδων Χανιά
              </Link>
              <Link to="/about" className="transition-colors hover:text-foreground">
                {t.nav.about}
              </Link>
            </div>
          </div>
          <div>
            <p className="label-eyebrow">{t.footer.start}</p>
            <div className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground">
              <Link to="/contact" className="transition-colors hover:text-foreground">
                {t.cta.start}
              </Link>
              <Link to="/contact" className="transition-colors hover:text-foreground">
                {t.nav.contact}
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-hairline">
        <div className="container-studio flex flex-col gap-2 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} LOLAS Digital Studio. {t.footer.rights}
          </p>
          <p className="tracking-[0.2em] uppercase">{t.footer.independent}</p>
        </div>
      </div>
    </footer>
  );
}
