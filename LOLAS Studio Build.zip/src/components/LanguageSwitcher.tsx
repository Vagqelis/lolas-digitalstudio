import { languages, useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({ className }: { className?: string }) {
  const { lang, setLang } = useI18n();

  return (
    <div className={cn("flex items-center gap-1", className)}>
      {languages.map((l, i) => (
        <span key={l.code} className="flex items-center gap-1">
          {i > 0 && <span className="text-xs text-muted-foreground/40">/</span>}
          <button
            type="button"
            onClick={() => setLang(l.code)}
            aria-label={l.label}
            aria-pressed={lang === l.code}
            className={cn(
              "text-xs font-medium tracking-[0.14em] transition-colors",
              lang === l.code
                ? "text-foreground"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {l.label}
          </button>
        </span>
      ))}
    </div>
  );
}
