import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";
import type { Package } from "@/lib/packages";

export function PackageCard({ pkg }: { pkg: Package }) {
  const { t } = useI18n();
  const copy = t.packages[pkg.id];

  return (
    <div
      className={cn(
        "flex flex-col border border-border p-8 transition-colors duration-300 hover:border-taupe/60",
        pkg.popular && "border-taupe/70 bg-card",
      )}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold tracking-[0.28em] text-taupe">
            {pkg.number}
          </p>
          <h3 className="mt-3 text-lg font-semibold tracking-[0.22em]">{pkg.name}</h3>
        </div>
        {pkg.popular && (
          <span className="border border-taupe/60 px-3 py-1 text-[0.6rem] font-semibold tracking-[0.2em] text-taupe">
            {t.packages.popular}
          </span>
        )}
      </div>

      <p className="mt-8 text-4xl font-bold tracking-tight">{pkg.price}</p>
      <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{copy.summary}</p>

      <ul className="mt-8 flex flex-1 flex-col gap-3 border-t border-hairline pt-8">
        {copy.features.map((f) => (
          <li key={f} className="flex gap-3 text-sm text-muted-foreground">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-taupe" strokeWidth={1.75} />
            <span>{f}</span>
          </li>
        ))}
      </ul>

      <Button
        asChild
        variant={pkg.popular ? "default" : "outline"}
        className="mt-10 w-full"
      >
        <Link to="/contact" search={{ pkg: pkg.id }}>
          {copy.cta}
        </Link>
      </Button>
    </div>
  );
}
