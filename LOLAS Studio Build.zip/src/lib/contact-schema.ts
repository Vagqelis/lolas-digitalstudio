import { z } from "zod";

import { packageOptions } from "@/lib/packages";

export const projectRequestSchema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(100),
  business: z.string().trim().max(120).optional().or(z.literal("")),
  email: z.string().trim().email("Please enter a valid email address").max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  package: z.enum(packageOptions as [string, ...string[]], {
    message: "Please select a package",
  }),
  message: z
    .string()
    .trim()
    .max(2000, "Please keep the message under 2000 characters")
    .optional()
    .or(z.literal("")),
  link: z.string().trim().max(300).optional().or(z.literal("")),
});

export type ProjectRequestInput = z.infer<typeof projectRequestSchema>;
