import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

export type Lang = "en" | "el" | "de";

export const languages: { code: Lang; label: string }[] = [
  { code: "en", label: "EN" },
  { code: "el", label: "ΕΛ" },
  { code: "de", label: "DE" },
];

const en = {
  nav: {
    home: "Home",
    services: "Services",
    packages: "Packages",
    about: "About",
    contact: "Contact",
  },
  cta: {
    start: "Start a Project",
    viewPackages: "View Packages",
    seeIncluded: "See what's included",
    backHome: "Back to home",
  },
  home: {
    eyebrow: "LOLAS — Digital Studio",
    h1: "Websites that make your business look professional.",
    lead: "Modern, fast and carefully designed websites built around your business — without unnecessary complexity.",
    approachEyebrow: "Approach",
    approachTitle: "Simple. Professional. Built for your business.",
    trust: [
      {
        title: "Clear communication",
        text: "Straight answers, no jargon, and one point of contact from start to launch.",
      },
      {
        title: "Modern design",
        text: "Restrained, contemporary layouts that make your business look established.",
      },
      {
        title: "Fast delivery",
        text: "Focused scope and a tight process, so your site goes live without delays.",
      },
      {
        title: "Mobile-first experience",
        text: "Built for phones first, then refined for tablet and desktop.",
      },
      {
        title: "Transparent pricing",
        text: "Fixed package prices published up front. No hidden extras.",
      },
    ],
    workEyebrow: "Selected work",
    workTitle: "Projects we have built.",
    workVisit: "Visit site",
    packagesEyebrow: "Packages",
    packagesTitle: "Transparent, fixed pricing.",
    ctaTitle: "Have an idea for your business?",
    ctaSubtitle: "Let's build it.",
  },
  services: {
    eyebrow: "Services",
    h1: "What we design, build and launch.",
    lead: "A focused set of services — done properly, without unnecessary complexity.",
    items: [
      {
        title: "Website design",
        text: "Clean, modern layouts built around your business, your services and the way your customers actually decide.",
        items: ["Custom design", "Responsive layouts", "Clear content structure"],
      },
      {
        title: "Business websites",
        text: "Multi-page websites with everything a customer needs: what you offer, who you are and how to reach you.",
        items: ["Multi-page structure", "Contact form", "Maps & social integration"],
      },
      {
        title: "Web applications",
        text: "When a standard website isn't enough — custom interfaces, forms and data handling shaped to your workflow.",
        items: ["Custom functionality", "Forms & data handling", "Deployment and setup"],
      },
      {
        title: "Performance & SEO basics",
        text: "Fast loading, sensible metadata and a mobile-first build so your site works well from day one.",
        items: ["Speed optimization", "Basic SEO setup", "Mobile-first build"],
      },
    ],
    processEyebrow: "Process",
    processTitle: "Four steps, no surprises.",
    process: [
      {
        title: "Conversation",
        text: "We talk about your business, your goals and what the site needs to do.",
      },
      {
        title: "Proposal",
        text: "A clear scope and a fixed price, based on one of the three packages.",
      },
      {
        title: "Design & build",
        text: "Design first, then build — with feedback along the way.",
      },
      { title: "Launch", text: "Deployment, setup and a final review together." },
    ],
    ctaTitle: "Not sure which service fits? Let's talk it through.",
  },
  about: {
    eyebrow: "About",
    h1: "A small independent studio, focused on doing fewer things properly.",
    paragraphs: [
      "LOLAS is a digital studio designing websites and web applications for businesses that need to look credible online — restaurants, services, trades, studios and small companies.",
      "The approach is deliberately simple: understand the business, define a clear scope, design something restrained and modern, then build it fast and launch it properly. No unnecessary complexity, no filler, no surprises in the invoice.",
      "Every project is treated as if the brand were our own — because how your website looks is how your business is judged before anyone speaks to you.",
    ],
    principles: [
      {
        title: "Small by choice",
        text: "You work directly with the person designing and building your site. Nothing gets lost in layers.",
      },
      {
        title: "Restraint over noise",
        text: "We remove what doesn't help your customer decide. What remains does the work.",
      },
      {
        title: "Honest scope",
        text: "Fixed prices, defined deliverables and no promises made before we understand the project.",
      },
    ],
    ctaTitle: "Let's talk about your business.",
  },
  packagesPage: {
    eyebrow: "Packages",
    h1: "Clear packages. Fixed prices.",
    gridTitle: "Choose your package",
    lead: "Choose the scope that matches your business. If you're unsure, we'll help you decide before anything starts.",
    noteEyebrow: "A note on the App package",
    noteText:
      "Custom applications differ from project to project. We don't promise specific functionality before understanding your needs — the final scope is defined together, in advance, before any work begins.",
    ctaTitle: "Ready when you are.",
  },
  packages: {
    popular: "MOST POPULAR",
    landing: {
      summary: "For businesses that need a professional online presence.",
      cta: "Choose Landing",
      features: [
        "One-page professional website",
        "Responsive design",
        "Mobile & desktop optimization",
        "Contact section",
        "WhatsApp / phone / email buttons",
        "Google Maps integration",
        "Basic SEO setup",
        "Fast delivery",
      ],
    },
    business: {
      summary: "For businesses that need a complete professional website.",
      cta: "Choose Business",
      features: [
        "Multi-page website",
        "Professional custom design",
        "Home page",
        "About section",
        "Services / products",
        "Contact page",
        "Contact form",
        "Google Maps integration",
        "Social media integration",
        "Mobile & desktop optimization",
        "Basic SEO",
        "Performance optimization",
      ],
    },
    app: {
      summary:
        "For businesses that need something more advanced than a standard website.",
      cta: "Discuss Your App",
      features: [
        "Custom web application",
        "Advanced functionality",
        "User-friendly interface",
        "Custom forms and data handling",
        "Responsive design",
        "Mobile & desktop optimization",
        "Custom business features",
        "Deployment and setup",
      ],
    },
  },
  contact: {
    eyebrow: "Contact",
    h1: "Start a project.",
    lead: "Tell us briefly what you need. We'll review it and reply as soon as possible, usually within the next few hours.",
    name: "Name",
    business: "Business / Company",
    email: "Email",
    phone: "Phone",
    package: "Package",
    message: "What do you need?",
    link: "Current website / Instagram / Facebook / other link",
    optional: "(optional)",
    namePlaceholder: "Your full name",
    businessPlaceholder: "Business name",
    messagePlaceholder: "Tell us briefly what you need (optional)",
    notSure: "Not sure yet",
    send: "Send Request",
    sending: "Sending…",
    error:
      "Your request could not be sent. Please try again, or email us directly.",
    successTitle: "Message received.",
    successText:
      "Thank you for contacting LOLAS Digital Studio. We'll get back to you shortly.",
    nextTitle: "What happens next",
    nextSteps: [
      "We read your request and check the details.",
      "You get a reply with a clear scope and next steps.",
      "If it's a fit, we agree the package and start.",
    ],
    privacy: "We only use your details to reply to this request.",
  },
  footer: {
    tagline:
      "Modern, fast and carefully designed websites built around your business.",
    studio: "Studio",
    start: "Start",
    rights: "All rights reserved.",
    independent: "Independent web design studio",
  },
  whatsapp: "Chat on WhatsApp",
};

type Dict = typeof en;

const el: Dict = {
  nav: {
    home: "Αρχική",
    services: "Υπηρεσίες",
    packages: "Πακέτα",
    about: "Σχετικά",
    contact: "Επικοινωνία",
  },
  cta: {
    start: "Ξεκίνα Έργο",
    viewPackages: "Δες τα Πακέτα",
    seeIncluded: "Δες τι περιλαμβάνεται",
    backHome: "Επιστροφή στην αρχική",
  },
  home: {
    eyebrow: "LOLAS — Digital Studio",
    h1: "Ιστοσελίδες που κάνουν την επιχείρησή σου να δείχνει επαγγελματική.",
    lead: "Μοντέρνες, γρήγορες και προσεγμένες ιστοσελίδες, φτιαγμένες γύρω από την επιχείρησή σου — χωρίς περιττή πολυπλοκότητα.",
    approachEyebrow: "Προσέγγιση",
    approachTitle: "Απλά. Επαγγελματικά. Για την επιχείρησή σου.",
    trust: [
      {
        title: "Καθαρή επικοινωνία",
        text: "Ξεκάθαρες απαντήσεις, χωρίς τεχνικούς όρους, με έναν συνομιλητή από την αρχή μέχρι το launch.",
      },
      {
        title: "Μοντέρνος σχεδιασμός",
        text: "Λιτά, σύγχρονα layouts που δίνουν κύρος στην επιχείρησή σου.",
      },
      {
        title: "Γρήγορη παράδοση",
        text: "Καθαρό scope και σφιχτή διαδικασία, ώστε το site να βγει online χωρίς καθυστερήσεις.",
      },
      {
        title: "Mobile-first εμπειρία",
        text: "Σχεδιασμός πρώτα για κινητό και μετά για tablet και desktop.",
      },
      {
        title: "Διαφανής τιμολόγηση",
        text: "Σταθερές τιμές πακέτων από την αρχή. Χωρίς κρυφές χρεώσεις.",
      },
    ],
    workEyebrow: "Έργα μας",
    workTitle: "Ιστοσελίδες που έχουμε φτιάξει.",
    workVisit: "Δες το site",
    packagesEyebrow: "Πακέτα",
    packagesTitle: "Διαφανείς, σταθερές τιμές.",
    ctaTitle: "Έχεις μια ιδέα για την επιχείρησή σου;",
    ctaSubtitle: "Ας τη φτιάξουμε.",
  },
  services: {
    eyebrow: "Υπηρεσίες",
    h1: "Τι σχεδιάζουμε, φτιάχνουμε και βγάζουμε online.",
    lead: "Λίγες, στοχευμένες υπηρεσίες — γίνονται σωστά, χωρίς περιττή πολυπλοκότητα.",
    items: [
      {
        title: "Σχεδιασμός ιστοσελίδας",
        text: "Καθαρά, μοντέρνα layouts γύρω από την επιχείρηση, τις υπηρεσίες σου και τον τρόπο που αποφασίζουν οι πελάτες σου.",
        items: ["Custom σχεδιασμός", "Responsive layouts", "Καθαρή δομή περιεχομένου"],
      },
      {
        title: "Εταιρικά websites",
        text: "Πολυσέλιδες ιστοσελίδες με ό,τι χρειάζεται ο πελάτης: τι προσφέρεις, ποιος είσαι και πώς σε βρίσκει.",
        items: ["Πολυσέλιδη δομή", "Φόρμα επικοινωνίας", "Χάρτες & social"],
      },
      {
        title: "Web εφαρμογές",
        text: "Όταν μια απλή ιστοσελίδα δεν αρκεί — custom interfaces, φόρμες και διαχείριση δεδομένων στα μέτρα σου.",
        items: ["Custom λειτουργίες", "Φόρμες & δεδομένα", "Εγκατάσταση & deployment"],
      },
      {
        title: "Ταχύτητα & βασικό SEO",
        text: "Γρήγορη φόρτωση, σωστά metadata και mobile-first κατασκευή ώστε να δουλεύει από την πρώτη μέρα.",
        items: ["Βελτιστοποίηση ταχύτητας", "Βασικό SEO", "Mobile-first κατασκευή"],
      },
    ],
    processEyebrow: "Διαδικασία",
    processTitle: "Τέσσερα βήματα, χωρίς εκπλήξεις.",
    process: [
      {
        title: "Συζήτηση",
        text: "Μιλάμε για την επιχείρησή σου, τους στόχους και τι πρέπει να κάνει το site.",
      },
      {
        title: "Πρόταση",
        text: "Καθαρό scope και σταθερή τιμή, με βάση ένα από τα τρία πακέτα.",
      },
      {
        title: "Σχεδιασμός & κατασκευή",
        text: "Πρώτα σχεδιασμός, μετά κατασκευή — με feedback στην πορεία.",
      },
      { title: "Launch", text: "Ανέβασμα, ρυθμίσεις και τελικός έλεγχος μαζί." },
    ],
    ctaTitle: "Δεν είσαι σίγουρος τι χρειάζεσαι; Ας το δούμε μαζί.",
  },
  about: {
    eyebrow: "Σχετικά",
    h1: "Ένα μικρό ανεξάρτητο studio, που κάνει λιγότερα πράγματα σωστά.",
    paragraphs: [
      "Το LOLAS είναι ένα digital studio που σχεδιάζει ιστοσελίδες και web εφαρμογές για επιχειρήσεις που θέλουν αξιόπιστη παρουσία online — εστιατόρια, υπηρεσίες, τεχνίτες, studios και μικρές εταιρείες.",
      "Η προσέγγιση είναι σκόπιμα απλή: καταλαβαίνουμε την επιχείρηση, ορίζουμε καθαρό scope, σχεδιάζουμε κάτι λιτό και μοντέρνο και το υλοποιούμε γρήγορα. Χωρίς περιττή πολυπλοκότητα και χωρίς εκπλήξεις στο τιμολόγιο.",
      "Κάθε έργο αντιμετωπίζεται σαν να είναι δικό μας brand — γιατί η ιστοσελίδα σου κρίνει την επιχείρησή σου πριν μιλήσει κανείς μαζί σου.",
    ],
    principles: [
      {
        title: "Μικροί από επιλογή",
        text: "Συνεργάζεσαι απευθείας με αυτόν που σχεδιάζει και φτιάχνει το site σου.",
      },
      {
        title: "Λιτότητα αντί θορύβου",
        text: "Αφαιρούμε ό,τι δεν βοηθά τον πελάτη σου να αποφασίσει. Ό,τι μένει, δουλεύει.",
      },
      {
        title: "Ειλικρινές scope",
        text: "Σταθερές τιμές, καθαρά παραδοτέα και καμία υπόσχεση πριν καταλάβουμε το έργο.",
      },
    ],
    ctaTitle: "Ας μιλήσουμε για την επιχείρησή σου.",
  },
  packagesPage: {
    eyebrow: "Πακέτα",
    h1: "Καθαρά πακέτα. Σταθερές τιμές.",
    gridTitle: "Διάλεξε το πακέτο σου",
    lead: "Διάλεξε το πακέτο που ταιριάζει στην επιχείρησή σου. Αν δεν είσαι σίγουρος, σε βοηθάμε να αποφασίσεις πριν ξεκινήσει οτιδήποτε.",
    noteEyebrow: "Σημείωση για το πακέτο App",
    noteText:
      "Οι custom εφαρμογές διαφέρουν από έργο σε έργο. Δεν υποσχόμαστε συγκεκριμένες λειτουργίες πριν καταλάβουμε τις ανάγκες σου — το τελικό scope ορίζεται μαζί, εκ των προτέρων.",
    ctaTitle: "Είμαστε έτοιμοι όποτε είσαι.",
  },
  packages: {
    popular: "ΠΙΟ ΔΗΜΟΦΙΛΕΣ",
    landing: {
      summary: "Για επιχειρήσεις που θέλουν επαγγελματική παρουσία online.",
      cta: "Επιλογή Landing",
      features: [
        "Επαγγελματική ιστοσελίδα μίας σελίδας",
        "Responsive σχεδιασμός",
        "Βελτιστοποίηση για κινητό & desktop",
        "Ενότητα επικοινωνίας",
        "Κουμπιά WhatsApp / τηλέφωνο / email",
        "Ενσωμάτωση Google Maps",
        "Βασικό SEO",
        "Γρήγορη παράδοση",
      ],
    },
    business: {
      summary: "Για επιχειρήσεις που θέλουν ολοκληρωμένη επαγγελματική ιστοσελίδα.",
      cta: "Επιλογή Business",
      features: [
        "Πολυσέλιδη ιστοσελίδα",
        "Επαγγελματικός custom σχεδιασμός",
        "Αρχική σελίδα",
        "Ενότητα «Σχετικά»",
        "Υπηρεσίες / προϊόντα",
        "Σελίδα επικοινωνίας",
        "Φόρμα επικοινωνίας",
        "Ενσωμάτωση Google Maps",
        "Ενσωμάτωση social media",
        "Βελτιστοποίηση για κινητό & desktop",
        "Βασικό SEO",
        "Βελτιστοποίηση ταχύτητας",
      ],
    },
    app: {
      summary: "Για επιχειρήσεις που θέλουν κάτι πιο προχωρημένο από απλή ιστοσελίδα.",
      cta: "Συζήτηση για App",
      features: [
        "Custom web εφαρμογή",
        "Προχωρημένες λειτουργίες",
        "Εύχρηστο περιβάλλον",
        "Custom φόρμες και διαχείριση δεδομένων",
        "Responsive σχεδιασμός",
        "Βελτιστοποίηση για κινητό & desktop",
        "Λειτουργίες στα μέτρα της επιχείρησης",
        "Εγκατάσταση & deployment",
      ],
    },
  },
  contact: {
    eyebrow: "Επικοινωνία",
    h1: "Ξεκίνα ένα έργο.",
    lead: "Πες μας σύντομα τι χρειάζεσαι. Θα το δούμε και θα απαντήσουμε το συντομότερο δυνατό, συνήθως μέσα σε λίγες ώρες.",
    name: "Όνομα",
    business: "Επιχείρηση / Εταιρεία",
    email: "Email",
    phone: "Τηλέφωνο",
    package: "Πακέτο",
    message: "Τι χρειάζεσαι;",
    link: "Ιστοσελίδα / Instagram / Facebook / άλλο link",
    optional: "(προαιρετικό)",
    namePlaceholder: "Το ονοματεπώνυμό σου",
    businessPlaceholder: "Όνομα επιχείρησης",
    messagePlaceholder: "Πες μας σύντομα τι χρειάζεσαι (προαιρετικό)",
    notSure: "Δεν είμαι σίγουρος ακόμα",
    send: "Αποστολή Αιτήματος",
    sending: "Αποστολή…",
    error: "Το αίτημα δεν στάλθηκε. Δοκίμασε ξανά ή στείλε μας email απευθείας.",
    successTitle: "Το μήνυμα ελήφθη.",
    successText:
      "Ευχαριστούμε που επικοινώνησες με το LOLAS Digital Studio. Θα σε ενημερώσουμε πολύ σύντομα.",
    nextTitle: "Τι ακολουθεί",
    nextSteps: [
      "Διαβάζουμε το αίτημά σου και ελέγχουμε τις λεπτομέρειες.",
      "Λαμβάνεις απάντηση με καθαρό scope και επόμενα βήματα.",
      "Αν ταιριάζει, συμφωνούμε το πακέτο και ξεκινάμε.",
    ],
    privacy: "Τα στοιχεία σου χρησιμοποιούνται μόνο για την απάντηση σε αυτό το αίτημα.",
  },
  footer: {
    tagline:
      "Μοντέρνες, γρήγορες και προσεγμένες ιστοσελίδες, φτιαγμένες γύρω από την επιχείρησή σου.",
    studio: "Studio",
    start: "Ξεκίνα",
    rights: "Με επιφύλαξη παντός δικαιώματος.",
    independent: "Ανεξάρτητο web design studio",
  },
  whatsapp: "Επικοινωνία στο WhatsApp",
};

const de: Dict = {
  nav: {
    home: "Start",
    services: "Leistungen",
    packages: "Pakete",
    about: "Über uns",
    contact: "Kontakt",
  },
  cta: {
    start: "Projekt starten",
    viewPackages: "Pakete ansehen",
    seeIncluded: "Leistungen ansehen",
    backHome: "Zurück zur Startseite",
  },
  home: {
    eyebrow: "LOLAS — Digital Studio",
    h1: "Websites, die Ihr Unternehmen professionell wirken lassen.",
    lead: "Moderne, schnelle und sorgfältig gestaltete Websites, gebaut rund um Ihr Unternehmen — ohne unnötige Komplexität.",
    approachEyebrow: "Ansatz",
    approachTitle: "Einfach. Professionell. Für Ihr Unternehmen gebaut.",
    trust: [
      {
        title: "Klare Kommunikation",
        text: "Klare Antworten, kein Fachjargon und ein Ansprechpartner von Anfang bis Launch.",
      },
      {
        title: "Modernes Design",
        text: "Zurückhaltende, zeitgemäße Layouts, die Ihr Unternehmen etabliert wirken lassen.",
      },
      {
        title: "Schnelle Umsetzung",
        text: "Klarer Umfang und straffer Prozess — Ihre Website geht ohne Verzögerung online.",
      },
      {
        title: "Mobile-First",
        text: "Zuerst fürs Handy gebaut, dann für Tablet und Desktop verfeinert.",
      },
      {
        title: "Transparente Preise",
        text: "Feste Paketpreise, im Voraus veröffentlicht. Keine versteckten Kosten.",
      },
    ],
    workEyebrow: "Referenzen",
    workTitle: "Projekte, die wir gebaut haben.",
    workVisit: "Website ansehen",
    packagesEyebrow: "Pakete",
    packagesTitle: "Transparente Festpreise.",
    ctaTitle: "Haben Sie eine Idee für Ihr Unternehmen?",
    ctaSubtitle: "Lassen Sie uns loslegen.",
  },
  services: {
    eyebrow: "Leistungen",
    h1: "Was wir gestalten, bauen und launchen.",
    lead: "Ein fokussiertes Leistungsangebot — sauber umgesetzt, ohne unnötige Komplexität.",
    items: [
      {
        title: "Website-Design",
        text: "Klare, moderne Layouts rund um Ihr Unternehmen, Ihre Leistungen und die Entscheidungswege Ihrer Kunden.",
        items: ["Individuelles Design", "Responsive Layouts", "Klare Inhaltsstruktur"],
      },
      {
        title: "Unternehmenswebsites",
        text: "Mehrseitige Websites mit allem, was Kunden brauchen: Angebot, Unternehmen und Kontakt.",
        items: ["Mehrseitige Struktur", "Kontaktformular", "Karten & Social Media"],
      },
      {
        title: "Web-Anwendungen",
        text: "Wenn eine Website nicht reicht — individuelle Oberflächen, Formulare und Datenverarbeitung.",
        items: ["Individuelle Funktionen", "Formulare & Daten", "Deployment & Setup"],
      },
      {
        title: "Performance & SEO-Basis",
        text: "Schnelle Ladezeiten, sinnvolle Metadaten und Mobile-First-Umsetzung ab Tag eins.",
        items: ["Geschwindigkeit", "Basis-SEO", "Mobile-First-Umsetzung"],
      },
    ],
    processEyebrow: "Ablauf",
    processTitle: "Vier Schritte, keine Überraschungen.",
    process: [
      {
        title: "Gespräch",
        text: "Wir sprechen über Ihr Unternehmen, Ihre Ziele und die Aufgabe der Website.",
      },
      {
        title: "Angebot",
        text: "Klarer Umfang und Festpreis auf Basis eines der drei Pakete.",
      },
      {
        title: "Design & Umsetzung",
        text: "Erst Design, dann Umsetzung — mit Feedback unterwegs.",
      },
      { title: "Launch", text: "Deployment, Einrichtung und gemeinsame Abnahme." },
    ],
    ctaTitle: "Unsicher, was passt? Sprechen wir darüber.",
  },
  about: {
    eyebrow: "Über uns",
    h1: "Ein kleines unabhängiges Studio, das weniger Dinge richtig macht.",
    paragraphs: [
      "LOLAS ist ein Digital Studio, das Websites und Web-Anwendungen für Unternehmen gestaltet, die online glaubwürdig auftreten wollen — Restaurants, Dienstleister, Handwerk, Studios und kleine Firmen.",
      "Der Ansatz ist bewusst einfach: das Unternehmen verstehen, klaren Umfang definieren, zurückhaltend und modern gestalten, schnell umsetzen und sauber launchen. Keine unnötige Komplexität, keine Überraschungen auf der Rechnung.",
      "Jedes Projekt wird behandelt, als wäre es unsere eigene Marke — denn Ihre Website entscheidet über den ersten Eindruck.",
    ],
    principles: [
      {
        title: "Bewusst klein",
        text: "Sie arbeiten direkt mit der Person, die Ihre Website gestaltet und baut.",
      },
      {
        title: "Ruhe statt Lärm",
        text: "Wir entfernen alles, was Ihren Kunden nicht bei der Entscheidung hilft.",
      },
      {
        title: "Ehrlicher Umfang",
        text: "Festpreise, klare Ergebnisse und keine Versprechen vor dem Verstehen des Projekts.",
      },
    ],
    ctaTitle: "Sprechen wir über Ihr Unternehmen.",
  },
  packagesPage: {
    eyebrow: "Pakete",
    h1: "Klare Pakete. Feste Preise.",
    gridTitle: "Wählen Sie Ihr Paket",
    lead: "Wählen Sie den Umfang, der zu Ihrem Unternehmen passt. Unsicher? Wir helfen Ihnen vor dem Start bei der Entscheidung.",
    noteEyebrow: "Hinweis zum App-Paket",
    noteText:
      "Individuelle Anwendungen unterscheiden sich von Projekt zu Projekt. Wir versprechen keine Funktionen, bevor wir Ihre Anforderungen kennen — der finale Umfang wird vorab gemeinsam festgelegt.",
    ctaTitle: "Bereit, wenn Sie es sind.",
  },
  packages: {
    popular: "AM BELIEBTESTEN",
    landing: {
      summary: "Für Unternehmen, die eine professionelle Online-Präsenz brauchen.",
      cta: "Landing wählen",
      features: [
        "Professionelle One-Page-Website",
        "Responsive Design",
        "Optimierung für Mobil & Desktop",
        "Kontaktbereich",
        "WhatsApp- / Telefon- / E-Mail-Buttons",
        "Google-Maps-Integration",
        "Basis-SEO",
        "Schnelle Lieferung",
      ],
    },
    business: {
      summary: "Für Unternehmen, die eine komplette professionelle Website brauchen.",
      cta: "Business wählen",
      features: [
        "Mehrseitige Website",
        "Professionelles individuelles Design",
        "Startseite",
        "Über-uns-Bereich",
        "Leistungen / Produkte",
        "Kontaktseite",
        "Kontaktformular",
        "Google-Maps-Integration",
        "Social-Media-Integration",
        "Optimierung für Mobil & Desktop",
        "Basis-SEO",
        "Performance-Optimierung",
      ],
    },
    app: {
      summary: "Für Unternehmen, die mehr als eine Standard-Website brauchen.",
      cta: "App besprechen",
      features: [
        "Individuelle Web-Anwendung",
        "Erweiterte Funktionen",
        "Benutzerfreundliche Oberfläche",
        "Individuelle Formulare und Datenverarbeitung",
        "Responsive Design",
        "Optimierung für Mobil & Desktop",
        "Individuelle Geschäftsfunktionen",
        "Deployment und Einrichtung",
      ],
    },
  },
  contact: {
    eyebrow: "Kontakt",
    h1: "Projekt starten.",
    lead: "Sagen Sie uns kurz, was Sie brauchen. Wir melden uns so schnell wie möglich, meist innerhalb weniger Stunden.",
    name: "Name",
    business: "Unternehmen / Firma",
    email: "E-Mail",
    phone: "Telefon",
    package: "Paket",
    message: "Was brauchen Sie?",
    link: "Website / Instagram / Facebook / anderer Link",
    optional: "(optional)",
    namePlaceholder: "Ihr vollständiger Name",
    businessPlaceholder: "Firmenname",
    messagePlaceholder: "Beschreiben Sie kurz Ihr Anliegen (optional)",
    notSure: "Noch unsicher",
    send: "Anfrage senden",
    sending: "Wird gesendet…",
    error:
      "Ihre Anfrage konnte nicht gesendet werden. Bitte erneut versuchen oder direkt per E-Mail.",
    successTitle: "Nachricht erhalten.",
    successText:
      "Danke für Ihre Anfrage an LOLAS Digital Studio. Wir melden uns in Kürze.",
    nextTitle: "Wie es weitergeht",
    nextSteps: [
      "Wir lesen Ihre Anfrage und prüfen die Details.",
      "Sie erhalten eine Antwort mit klarem Umfang und nächsten Schritten.",
      "Wenn es passt, vereinbaren wir das Paket und starten.",
    ],
    privacy: "Ihre Daten nutzen wir ausschließlich zur Beantwortung dieser Anfrage.",
  },
  footer: {
    tagline:
      "Moderne, schnelle und sorgfältig gestaltete Websites rund um Ihr Unternehmen.",
    studio: "Studio",
    start: "Start",
    rights: "Alle Rechte vorbehalten.",
    independent: "Unabhängiges Webdesign-Studio",
  },
  whatsapp: "Chat über WhatsApp",
};

const dictionaries: Record<Lang, Dict> = { en, el, de };

const STORAGE_KEY = "lolas-lang";

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: Dict };

const LanguageContext = createContext<Ctx>({
  lang: "en",
  setLang: () => {},
  t: en,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY) as Lang | null;
    if (stored && stored in dictionaries) setLangState(stored);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = (l: Lang) => {
    setLangState(l);
    window.localStorage.setItem(STORAGE_KEY, l);
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t: dictionaries[lang] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useI18n() {
  return useContext(LanguageContext);
}
