import { createServerFn } from "@tanstack/react-start";

import { projectRequestSchema } from "@/lib/contact-schema";

export const submitProjectRequest = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => projectRequestSchema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: row, error } = await supabaseAdmin
      .from("project_requests")
      .insert({
        name: data.name,
        business: data.business || null,
        email: data.email,
        phone: data.phone || null,
        package: data.package,
        message: data.message || "",
        link: data.link || null,
      })
      .select("id, created_at")
      .single();

    if (error || !row) {
      console.error("Failed to store project request", error);
      throw new Error("We could not send your request. Please try again.");
    }

    const { sendLeadEmails } = await import("@/lib/lead-email.server");
    const emails = await sendLeadEmails({
      ...data,
      submittedAt: row.created_at,
    });

    if (emails.ownerSent || emails.customerSent) {
      await supabaseAdmin
        .from("project_requests")
        .update({
          owner_email_sent: emails.ownerSent,
          customer_email_sent: emails.customerSent,
        })
        .eq("id", row.id);
    }

    return { ok: true as const, id: row.id };
  });
