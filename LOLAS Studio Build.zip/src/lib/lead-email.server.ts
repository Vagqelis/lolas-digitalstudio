/**
 * Server-only email delivery for project requests, sent through the connected
 * Gmail account via the Lovable connector gateway.
 *
 * Two emails per request:
 *   1. Confirmation to the customer ("thank you, we'll be in touch shortly")
 *   2. Full request details to the studio inbox (LOLAS_OWNER_EMAIL),
 *      with Reply-To set to the customer.
 */

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";

export type LeadEmailPayload = {
  name: string;
  business?: string | undefined;
  email: string;
  phone?: string | undefined;
  package: string;
  message?: string | undefined;
  link?: string | undefined;
  submittedAt: string;
};

export type LeadEmailResult = {
  ownerSent: boolean;
  customerSent: boolean;
};

export function getOwnerEmail(): string {
  return process.env["LOLAS_OWNER_EMAIL"] || "elolas@tuc.gr";
}

export function formatSubject(payload: LeadEmailPayload): string {
  const pkg = payload.package.split("—")[0]?.trim() || payload.package;
  const who = payload.business?.trim() || payload.name;
  return `New Project Request — ${pkg} — ${who}`;
}

const b64 = (s: string) =>
  btoa(Array.from(new TextEncoder().encode(s), (b) => String.fromCharCode(b)).join(""));

const header = (v: string) => (/^[\x00-\x7F]*$/.test(v) ? v : `=?UTF-8?B?${b64(v)}?=`);

function buildRaw(opts: {
  from: string;
  fromName: string;
  to: string;
  subject: string;
  html: string;
  replyTo?: string | undefined;
}): string {
  const lines = [
    `From: ${header(opts.fromName)} <${opts.from}>`,
    `To: ${opts.to}`,
    ...(opts.replyTo ? [`Reply-To: ${opts.replyTo}`] : []),
    `Subject: ${header(opts.subject)}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "",
    opts.html,
  ];
  return b64(lines.join("\r\n"))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function gatewayHeaders(): Record<string, string> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const connectionKey = process.env["GOOGLE_MAIL_API_KEY"];
  if (!lovableKey || !connectionKey) {
    throw new Error("Gmail connector credentials are not configured");
  }
  return {
    Authorization: `Bearer ${lovableKey}`,
    "X-Connection-Api-Key": connectionKey,
    "Content-Type": "application/json",
  };
}

/** Gmail can only send from the connected account's own address. */
async function getSenderAddress(): Promise<string> {
  const response = await fetch(`${GATEWAY_URL}/users/me/profile`, {
    headers: gatewayHeaders(),
  });
  if (!response.ok) {
    const errorBody = await response.text();
    console.error(`Gmail profile lookup failed [${response.status}]: ${errorBody}`);
    throw new Error(`Gmail profile lookup failed [${response.status}]`);
  }
  const profile = (await response.json()) as { emailAddress?: string };
  if (!profile.emailAddress) throw new Error("Gmail profile has no email address");
  return profile.emailAddress;
}

async function sendViaGmail(raw: string): Promise<void> {
  const response = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
    method: "POST",
    headers: gatewayHeaders(),
    body: JSON.stringify({ raw }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    console.error(`Gmail send failed [${response.status}]: ${errorBody}`);
    throw new Error(`Gmail send failed [${response.status}]: ${errorBody}`);
  }
}

const esc = (v: string) =>
  v
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const SHELL = (inner: string) => `<!doctype html>
<html><body style="margin:0;background:#f4f2ef;padding:32px 0;font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#1b1b1b;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
    <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="width:560px;max-width:92%;background:#ffffff;border:1px solid #e3ded7;">
      <tr><td style="background:#111111;padding:22px 32px;">
        <span style="color:#ffffff;font-size:13px;letter-spacing:.28em;text-transform:uppercase;">LOLAS</span>
        <span style="color:#b9a68f;font-size:13px;letter-spacing:.28em;text-transform:uppercase;">&nbsp;— Digital Studio</span>
      </td></tr>
      <tr><td style="padding:34px 32px 30px;">${inner}</td></tr>
      <tr><td style="border-top:1px solid #e3ded7;padding:20px 32px;font-size:11px;line-height:1.7;color:#8a8378;">
        LOLAS — Digital Studio · <a href="https://lolas-digitalstudio.com" style="color:#8a8378;">lolas-digitalstudio.com</a><br />
        WhatsApp: +30 698 708 5152 · Email: elolas@tuc.gr
      </td></tr>
    </table>
  </td></tr></table>
</body></html>`;

function customerHtml(p: LeadEmailPayload): string {
  const rows = [
    ["Package", p.package],
    ...(p.business?.trim() ? [["Business", p.business.trim()]] : []),
    ...(p.message?.trim() ? [["Your notes", p.message.trim()]] : []),
  ];
  return SHELL(`
    <p style="margin:0 0 18px;font-size:11px;letter-spacing:.24em;text-transform:uppercase;color:#b9a68f;">Request received</p>
    <h1 style="margin:0 0 18px;font-size:24px;font-weight:600;line-height:1.3;">Thank you, ${esc(p.name)}.</h1>
    <p style="margin:0 0 14px;font-size:15px;line-height:1.75;">
      We have received your project request and it is now with our team. We will review the details
      and get back to you shortly with next steps.
    </p>
    <p style="margin:0 0 26px;font-size:15px;line-height:1.75;">
      If anything is urgent, simply reply to this email or message us on WhatsApp.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #e3ded7;">
      ${rows
        .map(
          ([k, v]) => `<tr>
        <td style="padding:12px 0;border-bottom:1px solid #f0ece6;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#8a8378;width:130px;vertical-align:top;">${esc(String(k))}</td>
        <td style="padding:12px 0;border-bottom:1px solid #f0ece6;font-size:14px;line-height:1.7;">${esc(String(v)).replace(/\n/g, "<br />")}</td>
      </tr>`,
        )
        .join("")}
    </table>
    <p style="margin:26px 0 0;font-size:14px;line-height:1.8;">
      Kind regards,<br /><strong style="font-weight:600;">LOLAS — Digital Studio</strong>
    </p>
  `);
}

function ownerHtml(p: LeadEmailPayload): string {
  const rows: [string, string][] = [
    ["Name", p.name],
    ["Business", p.business?.trim() || "—"],
    ["Email", p.email],
    ["Phone", p.phone?.trim() || "—"],
    ["Package", p.package],
    ["Link", p.link?.trim() || "—"],
    ["Request", p.message?.trim() || "—"],
    ["Submitted", p.submittedAt],
  ];
  return SHELL(`
    <p style="margin:0 0 18px;font-size:11px;letter-spacing:.24em;text-transform:uppercase;color:#b9a68f;">New project request</p>
    <h1 style="margin:0 0 22px;font-size:22px;font-weight:600;line-height:1.35;">${esc(p.business?.trim() || p.name)}</h1>
    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="border-top:1px solid #e3ded7;">
      ${rows
        .map(
          ([k, v]) => `<tr>
        <td style="padding:12px 0;border-bottom:1px solid #f0ece6;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#8a8378;width:130px;vertical-align:top;">${esc(k)}</td>
        <td style="padding:12px 0;border-bottom:1px solid #f0ece6;font-size:14px;line-height:1.7;">${esc(v).replace(/\n/g, "<br />")}</td>
      </tr>`,
        )
        .join("")}
    </table>
    <p style="margin:26px 0 0;font-size:14px;">
      <a href="mailto:${esc(p.email)}" style="color:#111111;">Reply to ${esc(p.name)}</a>
    </p>
  `);
}

export async function sendLeadEmails(
  payload: LeadEmailPayload,
): Promise<LeadEmailResult> {
  const owner = getOwnerEmail();
  const from = await getSenderAddress();
  const fromName = "LOLAS — Digital Studio";


  let ownerSent = false;
  let customerSent = false;

  try {
    await sendViaGmail(
      buildRaw({
        from,
        fromName,
        to: owner,
        subject: formatSubject(payload),
        html: ownerHtml(payload),
        replyTo: payload.email,
      }),
    );
    ownerSent = true;
  } catch (error) {
    console.error("[lolas] Failed to send studio notification email", error);
  }

  try {
    await sendViaGmail(
      buildRaw({
        from,
        fromName,
        to: payload.email,
        subject: "We received your request — LOLAS Digital Studio",
        html: customerHtml(payload),
        replyTo: owner,
      }),
    );
    customerSent = true;
  } catch (error) {
    console.error("[lolas] Failed to send customer confirmation email", error);
  }

  return { ownerSent, customerSent };
}
