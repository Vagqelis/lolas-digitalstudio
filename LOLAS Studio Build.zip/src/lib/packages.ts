export type Package = {
  id: "landing" | "business" | "app";
  number: string;
  name: string;
  price: string;
  summary: string;
  features: string[];
  cta: string;
  popular?: boolean;
  formValue: string;
};

export const packages: Package[] = [
  {
    id: "landing",
    number: "01",
    name: "LANDING",
    price: "€250",
    summary: "For businesses that need a professional online presence.",
    features: [
      "One-page professional website",
      "Responsive design",
      "Mobile & desktop optimization",
      "Contact section",
      "WhatsApp / phone / email buttons",
      "Google Maps integration",
      "Basic SEO setup",
      "Fast delivery",
    ],
    cta: "Choose Landing",
    formValue: "Landing — €250",
  },
  {
    id: "business",
    number: "02",
    name: "BUSINESS",
    price: "€400",
    summary: "For businesses that need a complete professional website.",
    features: [
      "Multi-page website",
      "Professional custom design",
      "Home page",
      "About section",
      "Services / products",
      "Contact page",
      "Contact form",
      "Google Maps integration",
      "Social media integration",
      "Mobile & desktop optimization",
      "Basic SEO",
      "Performance optimization",
    ],
    cta: "Choose Business",
    popular: true,
    formValue: "Business — €400",
  },
  {
    id: "app",
    number: "03",
    name: "APP",
    price: "€800",
    summary:
      "For businesses that need something more advanced than a standard website.",
    features: [
      "Custom web application",
      "Advanced functionality",
      "User-friendly interface",
      "Custom forms and data handling",
      "Responsive design",
      "Mobile & desktop optimization",
      "Custom business features",
      "Deployment and setup",
    ],
    cta: "Discuss Your App",
    formValue: "App — €800",
  },
];

export const packageOptions = [
  ...packages.map((p) => p.formValue),
  "Not sure yet",
];
