import { createFileRoute, Link } from "@tanstack/react-router";

import { Button } from "@/components/ui/button";
import { LolasMark } from "@/components/LolasMark";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — LOLAS Digital Studio" },
      {
        name: "description",
        content:
          "Website design, multi-page business websites and custom web applications, designed and built by LOLAS Digital Studio.",
      },
      { property: "og:title", content: "Services — LOLAS Digital Studio" },
      {
        property: "og:description",
        content:
          "Website design, multi-page business websites and custom web applications by LOLAS Digital Studio.",
      },
    ],
  }),
  component: Services,
});

function Services() {
  const { t } = useI18n();

  return (
    <>
      <section className="border-b border-border">
        <div className="container-studio py-24 md:py-32">
          <p className="label-eyebrow">{t.services.eyebrow}</p>
          <h1 className="display-lg mt-6 max-w-2xl">{t.services.h1}</h1>
          <p className="body-lead mt-6 max-w-xl">{t.services.lead}</p>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio grid gap-px py-24 sm:grid-cols-2">
          {t.services.items.map((s) => (
            <div
              key={s.title}
              className="border-t border-hairline pt-8 sm:px-8 sm:first:pl-0 sm:[&:nth-child(odd)]:pl-0"
            >
              <LolasMark className="h-6 w-6" />
              <h2 className="mt-6 text-xl font-semibold tracking-tight">{s.title}</h2>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">
                {s.text}
              </p>
              <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2">
                {s.items.map((i) => (
                  <li key={i} className="text-xs tracking-[0.12em] uppercase text-taupe">
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-24">
          <p className="label-eyebrow">{t.services.processEyebrow}</p>
          <h2 className="display-md mt-6">{t.services.processTitle}</h2>
          <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            {t.services.process.map((p, i) => (
              <div key={p.title} className="border-t border-hairline pt-6">
                <p className="text-xs font-semibold tracking-[0.24em] text-taupe">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <h3 className="mt-4 text-base font-semibold">{p.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {p.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="surface-light">
        <div className="container-studio flex flex-col items-start gap-8 py-20 md:flex-row md:items-center md:justify-between">
          <h2 className="display-md max-w-lg">{t.services.ctaTitle}</h2>
          <Button asChild size="lg">
            <Link to="/contact">{t.cta.start}</Link>
          </Button>
        </div>
      </section>
    </>
  );
}
