import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { LolasMark } from "@/components/LolasMark";
import { PackageCard } from "@/components/PackageCard";
import { packages } from "@/lib/packages";
import { useI18n } from "@/lib/i18n";

const projects: { name: string; url: string; description: string }[] = [
  {
    name: "Ψησού Χανιά",
    url: "https://psisouchania.gr/",
    description: "psisouchania.gr",
  },
  {
    name: "BTO Agency",
    url: "https://btoagency.com/",
    description: "btoagency.com",
  },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Κατασκευή Ιστοσελίδων Χανιά | Web Design από 250€ — LOLAS" },
      {
        name: "description",
        content:
          "Κατασκευή ιστοσελίδων & web design στα Χανιά, Κρήτη. Σύγχρονα, γρήγορα sites από 250€, παράδοση 1–2 ημέρες, 2 εβδομάδες δωρεάν δοκιμή.",
      },
      {
        name: "keywords",
        content:
          "κατασκευή ιστοσελίδων Χανιά, web design Χανιά, ιστοσελίδες Κρήτη, web developer Χανιά, web maker Chania Greece",
      },
      { name: "geo.region", content: "GR-M" },
      { name: "geo.placename", content: "Chania" },
      {
        property: "og:title",
        content: "LOLAS — Digital Studio | Professional Websites for Business",
      },
      {
        property: "og:description",
        content:
          "Modern, fast and carefully designed websites built around your business — without unnecessary complexity.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://lolas-digitalstudio.com/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://lolas-digitalstudio.com/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": ["LocalBusiness", "ProfessionalService"],
          "@id": "https://lolas-digitalstudio.com/#business",
          name: "LOLAS — Digital Studio",
          alternateName: "LOLAS Digital Studio",
          description:
            "Web design and development studio building modern, high-quality and affordable websites and web applications. Delivery in 1–2 days with a 2-week free trial.",
          url: "https://lolas-digitalstudio.com/",
          
          email: "elolas@tuc.gr",
          telephone: "+30 698 708 5152",
          priceRange: "€250–€800",
          currenciesAccepted: "EUR",
          paymentAccepted: "Bank transfer, Card",
          knowsLanguage: ["en", "el", "de"],
          serviceType: [
            "Web Development",
            "Web Design",
            "Web Application Development",
            "SEO",
          ],
          address: {
            "@type": "PostalAddress",
            addressLocality: "Chania",
            addressRegion: "Crete",
            postalCode: "73100",
            addressCountry: "GR",
          },
          geo: {
            "@type": "GeoCoordinates",
            latitude: "35.5138",
            longitude: "24.0180",
          },
          openingHoursSpecification: [
            {
              "@type": "OpeningHoursSpecification",
              dayOfWeek: [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
              ],
              opens: "09:00",
              closes: "18:00",
            },
          ],
          areaServed: [
            { "@type": "Country", name: "Greece" },
            { "@type": "Country", name: "Germany" },
            { "@type": "Place", name: "Worldwide (remote)" },
          ],
          contactPoint: [
            {
              "@type": "ContactPoint",
              contactType: "sales",
              email: "elolas@tuc.gr",
              telephone: "+30 698 708 5152",
              availableLanguage: ["English", "Greek", "German"],
            },
          ],
          hasOfferCatalog: {
            "@type": "OfferCatalog",
            name: "Website packages",
            itemListElement: packages.map((pkg) => ({
              "@type": "Offer",
              name: pkg.name,
              description: pkg.summary,
              price: pkg.price.replace("€", ""),
              priceCurrency: "EUR",
              url: "https://lolas-digitalstudio.com/packages",
            })),
          },
        }),
      },
    ],
  }),
  component: Home,
});

function Home() {
  const { t } = useI18n();

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="container-studio flex flex-col justify-center py-28 md:py-40">
          <div className="rise-in max-w-3xl">
            <p className="label-eyebrow">{t.home.eyebrow}</p>
            <h1 className="display-xl mt-8">{t.home.h1}</h1>
            <p className="body-lead mt-8 max-w-xl">{t.home.lead}</p>
            <div className="mt-12 flex flex-wrap gap-4">
              <Button asChild size="lg">
                <Link to="/contact">{t.cta.start}</Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/packages">{t.cta.viewPackages}</Link>
              </Button>
            </div>
          </div>
        </div>
        <LolasMark className="pointer-events-none absolute -right-10 top-1/2 hidden h-[26rem] w-[26rem] -translate-y-1/2 text-foreground/[0.035] lg:block" />
      </section>

      {/* Trust */}
      <section className="border-b border-border">
        <div className="container-studio py-24">
          <div className="max-w-2xl">
            <p className="label-eyebrow">{t.home.approachEyebrow}</p>
            <h2 className="display-lg mt-6">{t.home.approachTitle}</h2>
          </div>
          <div className="mt-16 grid gap-x-12 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {t.home.trust.map((p, i) => (
              <div key={p.title} className="border-t border-hairline pt-6">
                <p className="text-xs font-semibold tracking-[0.24em] text-taupe">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <h3 className="mt-4 text-base font-semibold">{p.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {p.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Selected work */}
      <section className="border-b border-border">
        <div className="container-studio py-24">
          <div className="max-w-2xl">
            <p className="label-eyebrow">{t.home.workEyebrow}</p>
            <h2 className="display-lg mt-6">{t.home.workTitle}</h2>
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2">
            {projects.map((p) => (
              <a
                key={p.url}
                href={p.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col justify-between border border-hairline p-8 transition-colors hover:border-foreground"
              >
                <div>
                  <h3 className="text-lg font-semibold">{p.name}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {p.description}
                  </p>
                </div>
                <span className="mt-8 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors group-hover:text-foreground">
                  {t.home.workVisit}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>


      <section className="border-b border-border">
        <div className="container-studio py-24">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-xl">
              <p className="label-eyebrow">{t.home.packagesEyebrow}</p>
              <h2 className="display-lg mt-6">{t.home.packagesTitle}</h2>
            </div>
            <Link
              to="/packages"
              className="group inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {t.cta.seeIncluded}
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            {packages.map((pkg) => (
              <PackageCard key={pkg.id} pkg={pkg} />
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="surface-light">
        <div className="container-studio py-28 text-center">
          <LolasMark className="mx-auto h-10 w-10" />
          <h2 className="display-lg mt-10">{t.home.ctaTitle}</h2>
          <p className="display-lg text-muted-foreground">{t.home.ctaSubtitle}</p>
          <div className="mt-12">
            <Button asChild size="lg">
              <Link to="/contact">{t.cta.start}</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
