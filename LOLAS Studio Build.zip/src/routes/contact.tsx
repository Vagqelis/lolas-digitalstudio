import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { LolasMark } from "@/components/LolasMark";
import { packageOptions, packages } from "@/lib/packages";
import { useI18n } from "@/lib/i18n";
import { projectRequestSchema, type ProjectRequestInput } from "@/lib/contact-schema";
import { submitProjectRequest } from "@/lib/project-request.functions";

const searchSchema = z.object({
  pkg: z.enum(["landing", "business", "app"]).optional(),
});

export const Route = createFileRoute("/contact")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Start a Project — LOLAS Digital Studio" },
      {
        name: "description",
        content:
          "Tell LOLAS Digital Studio what your business needs. Send a short project request and we'll reply within a few hours.",
      },
      { property: "og:title", content: "Start a Project — LOLAS Digital Studio" },
      {
        property: "og:description",
        content:
          "Send a short project request and we'll get back to you as soon as possible.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  const { pkg } = Route.useSearch();
  const { t } = useI18n();
  const submit = useServerFn(submitProjectRequest);

  const optionLabel = (option: string) => {
    const found = packages.find((p) => p.formValue === option);
    return found ? `${found.name} — ${found.price}` : t.contact.notSure;
  };

  const preselected =
    packages.find((p) => p.id === pkg)?.formValue ?? "Not sure yet";

  const form = useForm<ProjectRequestInput>({
    resolver: zodResolver(projectRequestSchema),
    defaultValues: {
      name: "",
      business: "",
      email: "",
      phone: "",
      package: preselected,
      message: "",
      link: "",
    },
  });

  const mutation = useMutation({
    mutationFn: (values: ProjectRequestInput) => submit({ data: values }),
  });

  if (mutation.isSuccess) {
    return (
      <section className="border-b border-border">
        <div className="container-studio flex min-h-[70vh] flex-col items-center justify-center py-28 text-center">
          <span className="flex h-12 w-12 items-center justify-center border border-taupe/60">
            <Check className="h-5 w-5 text-taupe" strokeWidth={1.5} />
          </span>
          <h1 className="display-md mt-10">{t.contact.successTitle}</h1>
          <p className="body-lead mt-5 max-w-md">
            {t.contact.successText}
          </p>
          <div className="mt-10">
            <Button asChild variant="outline">
              <Link to="/">{t.cta.backHome}</Link>
            </Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="border-b border-border">
        <div className="container-studio py-24 md:py-28">
          <p className="label-eyebrow">{t.contact.eyebrow}</p>
          <h1 className="display-lg mt-6 max-w-2xl">{t.contact.h1}</h1>
          <p className="body-lead mt-6 max-w-xl">
            {t.contact.lead}
          </p>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio grid gap-16 py-20 lg:grid-cols-[1.4fr_1fr]">
          <form
            noValidate
            onSubmit={form.handleSubmit((values) => mutation.mutate(values))}
            className="space-y-8"
          >
            <div className="grid gap-8 sm:grid-cols-2">
              <Field
                htmlFor="contact-name"
                label={t.contact.name}
                error={form.formState.errors.name?.message}
              >
                <Input
                  id="contact-name"
                  {...form.register("name")}
                  placeholder={t.contact.namePlaceholder}
                />
              </Field>
              <Field
                htmlFor="contact-business"
                label={t.contact.business}
                optional
                error={form.formState.errors.business?.message}
              >
                <Input
                  id="contact-business"
                  {...form.register("business")}
                  placeholder={t.contact.businessPlaceholder}
                />
              </Field>
              <Field
                htmlFor="contact-email"
                label={t.contact.email}
                error={form.formState.errors.email?.message}
              >
                <Input
                  id="contact-email"
                  type="email"
                  {...form.register("email")}
                  placeholder="you@example.com"
                />
              </Field>
              <Field
                htmlFor="contact-phone"
                label={t.contact.phone}
                optional
                error={form.formState.errors.phone?.message}
              >
                <Input
                  id="contact-phone"
                  type="tel"
                  {...form.register("phone")}
                  placeholder="+30 ..."
                />
              </Field>
            </div>

            <Field label={t.contact.package} error={form.formState.errors.package?.message}>
              <div className="grid gap-3 sm:grid-cols-2">
                {packageOptions.map((option) => {
                  const selected = form.watch("package") === option;
                  return (
                    <label
                      key={option}
                      className={`flex cursor-pointer items-center gap-3 border px-4 py-3 text-sm transition-colors ${
                        selected
                          ? "border-taupe/70 bg-secondary text-foreground"
                          : "border-border text-muted-foreground hover:border-taupe/40"
                      }`}
                    >
                      <input
                        type="radio"
                        value={option}
                        {...form.register("package")}
                        className="sr-only"
                      />
                      <span
                        className={`h-2 w-2 shrink-0 ${
                          selected ? "bg-taupe" : "bg-muted-foreground/40"
                        }`}
                      />
                      {optionLabel(option)}
                    </label>
                  );
                })}
              </div>
            </Field>

            <Field
              htmlFor="contact-message"
              label={t.contact.message}
              optional
              error={form.formState.errors.message?.message}
            >
              <Textarea
                id="contact-message"
                rows={7}
                {...form.register("message")}
                placeholder={t.contact.messagePlaceholder}
              />
            </Field>

            <Field
              htmlFor="contact-link"
              label={t.contact.link}
              optional
              error={form.formState.errors.link?.message}
            >
              <Input
                id="contact-link"
                {...form.register("link")}
                placeholder="https://"
              />
            </Field>

            {mutation.isError && (
              <p className="border border-destructive/50 px-4 py-3 text-sm text-destructive">
                {t.contact.error}
              </p>
            )}

            <Button type="submit" size="lg" disabled={mutation.isPending}>
              {mutation.isPending ? t.contact.sending : t.contact.send}
            </Button>
          </form>

          <aside className="border-t border-hairline pt-10 lg:border-l lg:border-t-0 lg:pl-12 lg:pt-0">
            <LolasMark className="h-7 w-7" />
            <h2 className="mt-6 text-base font-semibold">{t.contact.nextTitle}</h2>
            <ol className="mt-6 space-y-6">
              {t.contact.nextSteps.map((step, i) => (
                <li key={step} className="flex gap-4 text-sm text-muted-foreground">
                  <span className="text-xs font-semibold tracking-[0.2em] text-taupe">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>
            <p className="mt-10 border-t border-hairline pt-6 text-xs leading-relaxed text-muted-foreground">
              {t.contact.privacy}
            </p>
          </aside>
        </div>
      </section>
    </>
  );
}

function Field({
  label,
  optional,
  error,
  htmlFor,
  children,
}: {
  label: string;
  optional?: boolean | undefined;
  error?: string | undefined;
  htmlFor?: string | undefined;
  children: React.ReactNode;
}) {
  const { t } = useI18n();
  const optionalLabel = t.contact.optional;
  const labelContent = (
    <>
      {label}
      {optional && <span className="ml-2 normal-case tracking-normal">{optionalLabel}</span>}
    </>
  );
  return (
    <div className="space-y-2">
      {htmlFor ? (
        <Label htmlFor={htmlFor} className="label-eyebrow">
          {labelContent}
        </Label>
      ) : (
        <p className="label-eyebrow">{labelContent}</p>
      )}
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
