import { createFileRoute, Link } from "@tanstack/react-router";

import { Button } from "@/components/ui/button";
import { LolasMark } from "@/components/LolasMark";
import { PackageCard } from "@/components/PackageCard";
import { packages } from "@/lib/packages";

const url = "https://lolas-digitalstudio.com/kataskevi-istoselidon-chania";

const faq = [
  {
    q: "Πόσο κοστίζει η κατασκευή ιστοσελίδας στα Χανιά;",
    a: "Οι τιμές μας είναι σταθερές και ξεκάθαρες: One-page site από 250€, πολυσέλιδο επαγγελματικό site 400€ και custom web application 800€. Χωρίς κρυφά κόστη.",
  },
  {
    q: "Σε πόσο χρόνο είναι έτοιμη η ιστοσελίδα;",
    a: "Συνήθως σε 1–2 ημέρες. Σχεδιάζουμε, αναπτύσσουμε και σας δίνουμε το site έτοιμο για δοκιμή.",
  },
  {
    q: "Πληρώνω πριν δω το αποτέλεσμα;",
    a: "Όχι. Χρησιμοποιείτε την ολοκληρωμένη ιστοσελίδα δωρεάν για 2 εβδομάδες και πληρώνετε μόνο εφόσον σας αρέσει.",
  },
  {
    q: "Εξυπηρετείτε επιχειρήσεις εκτός Χανίων;",
    a: "Ναι. Έχουμε έδρα στα Χανιά (73100) και συνεργαζόμαστε απομακρυσμένα με επιχειρήσεις σε όλη την Κρήτη, την Ελλάδα και τη Γερμανία.",
  },
  {
    q: "Περιλαμβάνεται SEO και mobile εμφάνιση;",
    a: "Ναι. Κάθε ιστοσελίδα είναι 100% responsive σε κινητό και desktop, με βασικό SEO setup, γρήγορη ταχύτητα φόρτωσης και σύνδεση με Google Maps.",
  },
  {
    q: "Αναλαμβάνετε domain και hosting;",
    a: "Ναι. Σας βοηθάμε στην επιλογή και σύνδεση του domain, ρυθμίζουμε το hosting και αναλαμβάνουμε ολόκληρη τη διαδικασία μέχρι η ιστοσελίδα να είναι online.",
  },
  {
    q: "Μπορώ να ανανεώνω μόνος μου το περιεχόμενο;",
    a: "Ναι. Σας δείχνουμε πώς να αλλάζετε κείμενα, φωτογραφίες και στοιχεία επικοινωνίας. Αν προτιμάτε, αναλαμβάνουμε εμείς τις αλλαγές κατόπιν συνεννόησης.",
  },
  {
    q: "Τι γίνεται μετά την παράδοση της ιστοσελίδας;",
    a: "Μένουμε διαθέσιμοι για διορθώσεις, μικρές προσθήκες και απορίες. Αν χρειαστεί κάτι νέο αργότερα (σελίδα, φόρμα, λειτουργία) το συζητάμε ξεχωριστά.",
  },
];

const services = [
  {
    title: "Κατασκευή Ιστοσελίδων Χανιά",
    text: "Σύγχρονες, γρήγορες επαγγελματικές ιστοσελίδες με custom σχεδιασμό — χωρίς έτοιμα templates. Παίρνετε δομή σελίδων, κείμενα σε σωστή σειρά και ξεκάθαρα σημεία επικοινωνίας.",
  },
  {
    title: "Website Development",
    text: "Καθαρός, γρήγορος κώδικας αντί για βαριά plugins. Το site φορτώνει άμεσα, δουλεύει σε κάθε browser και συντηρείται εύκολα στο μέλλον.",
  },
  {
    title: "Web Design & UI/UX",
    text: "Μινιμαλ, premium αισθητική που κάνει τη μικρομεσαία επιχείρηση να δείχνει μεγάλη, με διαδρομή που οδηγεί τον επισκέπτη στην κλήση ή στη φόρμα.",
  },
  {
    title: "Web Applications",
    text: "Custom εφαρμογές, φόρμες, κρατήσεις, καταλόγους, διαχείριση δεδομένων και αυτοματισμούς για τις ανάγκες της επιχείρησής σας.",
  },
  {
    title: "SEO & Ταχύτητα",
    text: "Τεχνικό SEO, δομημένα δεδομένα, τοπική στόχευση για αναζητήσεις στα Χανιά, βελτιστοποίηση εικόνων και χρόνων φόρτωσης.",
  },
  {
    title: "Mobile-first & Launch",
    text: "Άψογη εμφάνιση σε κινητό, tablet και υπολογιστή, σύνδεση domain, hosting setup, παράδοση και υποστήριξη μετά το launch.",
  },
];

const businessTypes = [
  "Εστιατόρια, καφέ και ταβέρνες",
  "Ενοικιάσεις αυτοκινήτων & μοτοσυκλετών",
  "Καταλύματα, βίλες και ξενοδοχεία",
  "Τουριστικές εκδρομές & δραστηριότητες",
  "Ιατρεία, φυσικοθεραπεία και υπηρεσίες υγείας",
  "Συνεργεία, τεχνίτες και κατασκευές",
  "Δικηγορικά & λογιστικά γραφεία",
  "Καταστήματα και μικρές τοπικές επιχειρήσεις",
];

export const Route = createFileRoute("/kataskevi-istoselidon-chania")({
  head: () => ({
    meta: [
      {
        title: "Κατασκευή Ιστοσελίδων & Web Design Χανιά | LOLAS",
      },
      {
        name: "description",
        content:
          "Κατασκευή ιστοσελίδων και web design στα Χανιά, Κρήτη. Επαγγελματικές ιστοσελίδες για επιχειρήσεις από 250€, παράδοση σε 1–2 ημέρες και 2 εβδομάδες δωρεάν δοκιμή πριν πληρώσετε.",
      },
      {
        name: "keywords",
        content:
          "κατασκευή ιστοσελίδων Χανιά, κατασκευή website Χανιά, web design Χανιά, website development Χανιά, ιστοσελίδες για επιχειρήσεις στα Χανιά, ιστοσελίδες Κρήτη",
      },
      {
        property: "og:title",
        content: "Κατασκευή Ιστοσελίδων & Web Design Χανιά — LOLAS Digital Studio",
      },
      {
        property: "og:description",
        content:
          "Επαγγελματικές ιστοσελίδες για επιχειρήσεις στα Χανιά από 250€. Παράδοση 1–2 ημέρες, 2 εβδομάδες δωρεάν δοκιμή.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: url },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "geo.region", content: "GR-M" },
      { name: "geo.placename", content: "Chania" },
    ],
    links: [{ rel: "canonical", href: url }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "LocalBusiness",
              "@id": "https://lolas-digitalstudio.com/#business",
              name: "LOLAS — Digital Studio",
              url: "https://lolas-digitalstudio.com/",
              telephone: "+30 698 708 5152",
              email: "elolas@tuc.gr",
              description:
                "Κατασκευή ιστοσελίδων, web design και custom web applications για επιχειρήσεις στα Χανιά και σε όλη την Κρήτη.",
              address: {
                "@type": "PostalAddress",
                addressLocality: "Chania",
                addressRegion: "Crete",
                postalCode: "73100",
                addressCountry: "GR",
              },
              geo: {
                "@type": "GeoCoordinates",
                latitude: 35.5138,
                longitude: 24.018,
              },
              areaServed: [
                { "@type": "City", name: "Chania" },
                { "@type": "City", name: "Rethymno" },
                { "@type": "City", name: "Heraklion" },
                { "@type": "AdministrativeArea", name: "Crete" },
                { "@type": "Country", name: "Greece" },
              ],
            },
            {
              "@type": "Service",
              name: "Κατασκευή Ιστοσελίδων Χανιά",
              serviceType: "Web Design & Website Development",
              provider: { "@id": "https://lolas-digitalstudio.com/#business" },
              areaServed: [
                { "@type": "City", name: "Chania" },
                { "@type": "AdministrativeArea", name: "Crete" },
                { "@type": "Country", name: "Greece" },
              ],
              offers: packages.map((pkg) => ({
                "@type": "Offer",
                name: pkg.name,
                price: pkg.price.replace("€", ""),
                priceCurrency: "EUR",
                url,
              })),
            },
            {
              "@type": "FAQPage",
              mainEntity: faq.map((item) => ({
                "@type": "Question",
                name: item.q,
                acceptedAnswer: { "@type": "Answer", text: item.a },
              })),
            },
            {
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "Αρχική",
                  item: "https://lolas-digitalstudio.com/",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "Κατασκευή Ιστοσελίδων Χανιά",
                  item: url,
                },
              ],
            },
          ],
        }),
      },
    ],
  }),
  component: ChaniaLanding,
});

function ChaniaLanding() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-border">
        <div className="container-studio py-24 md:py-32">
          <p className="label-eyebrow">Χανιά · Κρήτη · 73100</p>
          <h1 className="display-xl mt-8 max-w-3xl">
            Κατασκευή Ιστοσελίδων &amp; Web Design στα Χανιά
          </h1>
          <p className="body-lead mt-8 max-w-xl">
            Σύγχρονες, γρήγορες και προσιτές επαγγελματικές ιστοσελίδες για
            επιχειρήσεις στα Χανιά και σε όλη την Κρήτη. Παράδοση σε 1–2 ημέρες
            και 2 εβδομάδες δωρεάν δοκιμή πριν πληρώσετε.
          </p>
          <div className="mt-12 flex flex-wrap gap-4">
            <Button asChild size="lg">
              <Link to="/contact">Ζητήστε προσφορά</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a href="https://wa.me/306987085152">WhatsApp</a>
            </Button>
          </div>
        </div>
        <LolasMark className="pointer-events-none absolute -right-10 top-1/2 hidden h-[26rem] w-[26rem] -translate-y-1/2 text-foreground/[0.035] lg:block" />
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-24">
          <h2 className="display-lg max-w-2xl">
            Υπηρεσίες web design &amp; website development
          </h2>
          <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            Αναλαμβάνουμε τη σχεδίαση και την κατασκευή website από την αρχή: δομή,
            κείμενα, εικόνες, φόρμες και σύνδεση με τα κανάλια επικοινωνίας σας.
            Δείτε αναλυτικά{" "}
            <Link to="/services" className="text-taupe underline underline-offset-4">
              όλες τις υπηρεσίες μας
            </Link>
            .
          </p>
          <div className="mt-16 grid gap-x-12 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((s, i) => (
              <div key={s.title} className="border-t border-hairline pt-6">
                <p className="text-xs font-semibold tracking-[0.24em] text-taupe">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <h3 className="mt-4 text-base font-semibold">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {s.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-24">
          <h2 className="display-lg max-w-2xl">
            Ιστοσελίδες για επιχειρήσεις στα Χανιά
          </h2>
          <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            Κάθε επιχείρηση έχει διαφορετική ανάγκη: κάποιες θέλουν μια καθαρή
            σελίδα παρουσίασης με τηλέφωνο και τοποθεσία, άλλες κατάλογο υπηρεσιών,
            φόρμα κρατήσεων ή πολύγλωσσο site για επισκέπτες από το εξωτερικό.
            Σχεδιάζουμε ανάλογα με τον τρόπο που σας βρίσκουν οι πελάτες σας.
          </p>
          <ul className="mt-12 grid gap-x-12 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
            {businessTypes.map((b) => (
              <li
                key={b}
                className="border-t border-hairline pt-4 text-sm text-muted-foreground"
              >
                {b}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-24">
          <h2 className="display-lg max-w-2xl">Τοπική παρουσία στα Χανιά</h2>
          <div className="mt-8 max-w-2xl space-y-4 text-sm leading-relaxed text-muted-foreground">
            <p>
              Έχουμε έδρα στα Χανιά (73100) και γνωρίζουμε την τοπική αγορά: την
              εποχικότητα του τουρισμού, το κοινό που ψάχνει από κινητό και τη
              σημασία του να σε βρίσκουν στις αναζητήσεις της περιοχής.
            </p>
            <p>
              Εξυπηρετούμε επιχειρήσεις στα Χανιά, στο Ρέθυμνο, στο Ηράκλειο και σε
              όλη την Κρήτη, με δια ζώσης συνάντηση όπου είναι εφικτό και
              απομακρυσμένη συνεργασία όπου βολεύει καλύτερα.
            </p>
            <p>
              Δείτε δουλειές μας όπως το{" "}
              <a
                href="https://psisouchania.gr/"
                className="text-taupe underline underline-offset-4"
                rel="noopener"
              >
                psisouchania.gr
              </a>{" "}
              και το{" "}
              <a
                href="https://btoagency.com/"
                className="text-taupe underline underline-offset-4"
                rel="noopener"
              >
                btoagency.com
              </a>
              , ή{" "}
              <Link to="/contact" className="text-taupe underline underline-offset-4">
                επικοινωνήστε μαζί μας
              </Link>{" "}
              για μια πρόταση στα μέτρα σας.
            </p>
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-24">
          <h2 className="display-lg max-w-2xl">Τιμές &amp; πακέτα</h2>
          <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            Σταθερές τιμές, χωρίς κρυφά κόστη. Πληρώνετε μόνο εφόσον σας αρέσει το
            αποτέλεσμα, μετά από 2 εβδομάδες δωρεάν δοκιμή.
          </p>
          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            {packages.map((pkg) => (
              <PackageCard key={pkg.id} pkg={pkg} />
            ))}
          </div>
          <p className="mt-10 text-sm text-muted-foreground">
            <Link to="/packages" className="text-taupe underline underline-offset-4">
              Δείτε αναλυτικά τα πακέτα και τι περιλαμβάνει το καθένα
            </Link>
          </p>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-24">
          <h2 className="display-lg max-w-2xl">Συχνές ερωτήσεις</h2>
          <div className="mt-14 max-w-3xl divide-y divide-hairline border-t border-hairline">
            {faq.map((item) => (
              <div key={item.q} className="py-8">
                <h3 className="text-base font-semibold">{item.q}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {item.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="surface-light">
        <div className="container-studio py-28 text-center">
          <LolasMark className="mx-auto h-10 w-10" />
          <h2 className="display-lg mt-10">
            Έτοιμοι για τη νέα σας ιστοσελίδα;
          </h2>
          <p className="body-lead mx-auto mt-6 max-w-md">
            Στείλτε ένα σύντομο αίτημα και απαντάμε άμεσα.
          </p>
          <div className="mt-12">
            <Button asChild size="lg">
              <Link to="/contact">Ξεκινήστε τώρα</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
