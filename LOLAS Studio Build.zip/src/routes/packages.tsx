import { createFileRoute, Link } from "@tanstack/react-router";

import { Button } from "@/components/ui/button";
import { PackageCard } from "@/components/PackageCard";
import { packages } from "@/lib/packages";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/packages")({
  head: () => ({
    meta: [
      { title: "Packages & Pricing — LOLAS Digital Studio" },
      {
        name: "description",
        content:
          "Three fixed-price packages: Landing €250, Business €400 and App €800. See exactly what is included in each.",
      },
      { property: "og:title", content: "Packages & Pricing — LOLAS Digital Studio" },
      {
        property: "og:description",
        content:
          "Landing €250, Business €400, App €800 — transparent packages from LOLAS Digital Studio.",
      },
    ],
  }),
  component: Packages,
});

function Packages() {
  const { t } = useI18n();

  return (
    <>
      <section className="border-b border-border">
        <div className="container-studio py-24 md:py-32">
          <p className="label-eyebrow">{t.packagesPage.eyebrow}</p>
          <h1 className="display-lg mt-6 max-w-2xl">{t.packagesPage.h1}</h1>
          <p className="body-lead mt-6 max-w-xl">{t.packagesPage.lead}</p>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-20">
          <h2 className="display-md max-w-xl">{t.packagesPage.gridTitle}</h2>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {packages.map((pkg) => (
              <PackageCard key={pkg.id} pkg={pkg} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio py-16">
          <div className="max-w-2xl border-l border-taupe/60 pl-6">
            <p className="label-eyebrow">{t.packagesPage.noteEyebrow}</p>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              {t.packagesPage.noteText}
            </p>
          </div>
        </div>
      </section>

      <section className="surface-light">
        <div className="container-studio flex flex-col items-start gap-8 py-20 md:flex-row md:items-center md:justify-between">
          <h2 className="display-md max-w-lg">{t.packagesPage.ctaTitle}</h2>
          <Button asChild size="lg">
            <Link to="/contact">{t.cta.start}</Link>
          </Button>
        </div>
      </section>
    </>
  );
}
