import { createFileRoute, Link } from "@tanstack/react-router";

import { Button } from "@/components/ui/button";
import { LolasMark } from "@/components/LolasMark";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — LOLAS Digital Studio" },
      {
        name: "description",
        content:
          "LOLAS is a small independent digital studio designing modern, honest websites for businesses that want to look professional online.",
      },
      { property: "og:title", content: "About — LOLAS Digital Studio" },
      {
        property: "og:description",
        content:
          "A small independent digital studio focused on clear communication, modern design and fast delivery.",
      },
    ],
  }),
  component: About,
});

function About() {
  const { t } = useI18n();

  return (
    <>
      <section className="border-b border-border">
        <div className="container-studio py-24 md:py-32">
          <p className="label-eyebrow">{t.about.eyebrow}</p>
          <h1 className="display-lg mt-6 max-w-3xl">{t.about.h1}</h1>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="container-studio grid gap-16 py-24 lg:grid-cols-[1.1fr_1fr]">
          <div className="space-y-6">
            {t.about.paragraphs.map((p) => (
              <p key={p} className="body-lead">
                {p}
              </p>
            ))}
          </div>

          <div className="flex flex-col gap-10 border-t border-hairline pt-10 lg:border-l lg:border-t-0 lg:pl-12 lg:pt-0">
            {t.about.principles.map((p) => (
              <div key={p.title}>
                <LolasMark className="h-5 w-5" />
                <h2 className="mt-4 text-base font-semibold">{p.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {p.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="surface-light">
        <div className="container-studio flex flex-col items-start gap-8 py-20 md:flex-row md:items-center md:justify-between">
          <h2 className="display-md max-w-lg">{t.about.ctaTitle}</h2>
          <Button asChild size="lg">
            <Link to="/contact">{t.cta.start}</Link>
          </Button>
        </div>
      </section>
    </>
  );
}
